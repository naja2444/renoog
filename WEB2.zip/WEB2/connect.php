<?php
	    define ('SERVEUR_BD','localhost');
	    define ('LOGIN_BD','root');
	    define ('PASS_BD','');
	    define ('NOM_BD','test'); 